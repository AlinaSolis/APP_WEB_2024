<?php
$servername = "localhost";
$username = "root"; // Cambia esto por tu usuario de MariaDB
$password = ""; // Cambia esto por tu contraseña de MariaDB
$dbname = "papeleria";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['fecha'])) {
    $fecha = $_GET['fecha'];
    $startDate = date('Y-m-d', strtotime('monday this week', strtotime($fecha)));
    $endDate = date('Y-m-d', strtotime('sunday this week', strtotime($fecha)));

    $sql = "SELECT DAYNAME(fecha_venta) as dia_semana, SUM(total) as ventas 
            FROM ventas 
            WHERE fecha_venta BETWEEN '$startDate' AND '$endDate' 
            GROUP BY dia_semana 
            ORDER BY FIELD(dia_semana, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')";
    $result = $conn->query($sql);

    $ventas = array_fill(0, 7, 0); // Inicializa los datos con ceros

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $index = array_search($row['dia_semana'], ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
            if ($index !== false) {
                $ventas[$index] = (int)$row['ventas'];
            }
        }
    }

    $conn->close();
    echo json_encode(array("ventas" => $ventas));
}
?>
